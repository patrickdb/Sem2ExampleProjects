﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RepositoryExample
{
    class SQLFileContext : IFileContext
    {
        public void addFile(File newFile)
        {
            throw new NotImplementedException();
        }
    }
}
