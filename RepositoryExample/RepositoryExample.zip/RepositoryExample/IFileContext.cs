﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RepositoryExample
{
    interface IFileContext
    {
        public void addFile(File newFile);
    }
}
